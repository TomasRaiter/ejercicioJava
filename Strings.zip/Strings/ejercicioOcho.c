/*
8. Realizar un programa que ingrese 5 palabras y devuelta la cadena de
caracteres repetidos más larga entre ellas (si ingreso metro, metralleta Y
metido debe devolver la cadena “met”)
*/

#include <stdio.h>
#include <string.h> 
#include <ctype.h>

int main(){


    return 0;
}