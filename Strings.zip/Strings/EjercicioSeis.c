/*
6. Crea un programa que invierta el orden de las palabras en una cadena (por
ejemplo, "Hola mundo", se convierte en "mundo Hola").
*/

#include <stdio.h>
#include <string.h>	
#include <ctype.h>

int main(){
char letra, palabras[150],newPal[150];
int contVocales = 0 , posFn ;


printf("Ingrese cadema de caracteres que quiere dar vuelta ");
fgets(palabras, sizeof(palabras), stdin); 
palabras[strcspn(palabras, "\n")] = '\0';

posFn = strlen(palabras);


return 0;
}